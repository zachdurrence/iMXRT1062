"""
Validates two things about swapping grblHAL's quantized-jerk ramp math for a
closed-form quintic-Bezier ramp (Marlin-style):

1. Multi-axis lockstep is unaffected. grblHAL drives ALL axes off one shared
   scalar "distance along block" clock via a Bresenham DDA
   (st.counter.x/y/z += steps.value[idx] each tick, compared to
   step_event_count -- see stepper.c lines ~609-704). steps.value[idx] and
   step_event_count are fixed once per block at load time (stepper.c lines
   937-945) and are NEVER touched by the ramp/jerk math. So whatever function
   generates mm_remaining(t), each axis's step count stays locked to its
   commanded ratio -- this is a structural property of the existing
   architecture, not something either ramp implementation can break.

2. The Bezier ramp actually removes the acceleration "stairstep" quantization
   that the current segment-based jerk implementation produces.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DT_SEGMENT = 0.01 / 60.0   # 10 ms, expressed in minutes (grblHAL's native time unit)

# ---------------------------------------------------------------------------
# Model A: grblHAL's current quantized-jerk ramp (replicated from stepper.c
# Ramp_Accel, ENABLE_JERK_ACCELERATION branch)
# ---------------------------------------------------------------------------
def simulate_quantized_jerk(v0, v1, accel, jerk, mm_total):
    t, v, a, mm = [0.0], [v0], [0.0], [0.0]
    current_speed = v0
    last_accel = 0.0
    mm_remaining = mm_total
    accelerate_until = 0.0  # we simulate a pure accel ramp to v1, then stop
    time_now = 0.0
    while mm_remaining > accelerate_until and current_speed < v1:
        time_var = DT_SEGMENT
        accel_var = jerk * time_var
        time_to_jerk = last_accel / jerk if jerk > 0 else 0.0
        jerk_rampdown = time_to_jerk * (current_speed + 0.5 * last_accel * time_to_jerk
                                         + jerk * time_to_jerk**2 / 6.0)
        if (mm_remaining - accelerate_until) > jerk_rampdown:
            last_accel = min(last_accel + accel_var, accel)
        else:
            last_accel = max(last_accel - accel_var, accel_var)
        speed_var = last_accel * time_var
        mm_remaining -= time_var * (current_speed + 0.5 * speed_var)
        current_speed = min(current_speed + speed_var, v1)
        time_now += time_var
        t.append(time_now); v.append(current_speed); a.append(last_accel)
        mm.append(mm_total - mm_remaining)
        if time_now > 10:  # safety break
            break
    return np.array(t), np.array(v), np.array(a), np.array(mm)

# ---------------------------------------------------------------------------
# Model B: closed-form quintic Bezier ramp (this patch)
# ---------------------------------------------------------------------------
def bezier_velocity(v0, v1, tau):
    tau3 = tau**3
    return v0 + (v1 - v0) * tau3 * (10 - 15*tau + 6*tau*tau)

def bezier_distance(v0, v1, T, tau):
    tau4 = tau**4
    return v0 * T * tau + (v1 - v0) * T * (tau4*tau*tau - 3*tau4*tau + 2.5*tau4)

def simulate_bezier_jerk(v0, v1, accel, mm_total):
    # The quintic smootherstep's peak slope is 15/8 = 1.875x its average slope
    # (verified symbolically: d/dtau[6t^5-15t^4+10t^3] peaks at tau=0.5).
    # Using T = dv/accel directly would let peak acceleration overshoot the
    # commanded limit by 87.5% -- derate T so peak accel equals `accel`.
    T = 1.875 * (v1 - v0) / accel
    t, v, mm = [0.0], [v0], [0.0]
    elapsed = 0.0
    prev_v = v0
    a_trace = [0.0]
    while elapsed < T:
        new_elapsed = min(elapsed + DT_SEGMENT, T)
        tau0, tau1 = elapsed / T, new_elapsed / T
        d0 = bezier_distance(v0, v1, T, tau0)
        d1 = bezier_distance(v0, v1, T, tau1)
        speed = bezier_velocity(v0, v1, tau1)
        a_trace.append((speed - prev_v) / (new_elapsed - elapsed))
        prev_v = speed
        elapsed = new_elapsed
        mm.append(mm[-1] + (d1 - d0))
        t.append(elapsed); v.append(speed)
    return np.array(t), np.array(v), np.array(a_trace), np.array(mm)

# ---------------------------------------------------------------------------
# Multi-axis lockstep check: drive a Bresenham DDA off each model's position
# trace and confirm every axis stays within 1 step of its commanded ratio.
# ---------------------------------------------------------------------------
def bresenham_axis_check(mm_trace, steps_per_mm, axis_ratios, step_event_count):
    """axis_ratios: dict axis -> steps.value[idx]/step_event_count for that axis
       (fixed once per block, exactly as in stepper.c)."""
    total_steps = mm_trace[-1] * steps_per_mm
    counters = {ax: 0.0 for ax in axis_ratios}
    executed = {ax: 0 for ax in axis_ratios}
    max_dev = {ax: 0 for ax in axis_ratios}
    prev_dominant_steps = 0
    for m in mm_trace:
        dominant_steps = int(m * steps_per_mm)
        d_steps = dominant_steps - prev_dominant_steps
        prev_dominant_steps = dominant_steps
        for ax, ratio in axis_ratios.items():
            counters[ax] += ratio * d_steps
            while counters[ax] >= 1.0:
                counters[ax] -= 1.0
                executed[ax] += 1
            ideal = ratio * dominant_steps
            max_dev[ax] = max(max_dev[ax], abs(executed[ax] - ideal))
    return executed, max_dev

# ---------------------------------------------------------------------------
# Run: a 3-axis diagonal move, X:Y:Z step ratio 3:2:1 (arbitrary line)
# ---------------------------------------------------------------------------
v0, v1, accel, jerk = 0.0, 3000.0, 1500.0, 15000.0   # mm/min, mm/min^2, mm/min^3
mm_total = 5000.0   # generous headroom so the ramp completes on speed, not distance
steps_per_mm = 80.0
axis_ratios = {"X": 1.0, "Y": 2/3, "Z": 1/3}  # steps.value[idx]/step_event_count, fixed per block

t_q, v_q, a_q, mm_q = simulate_quantized_jerk(v0, v1, accel, jerk, mm_total)
t_b, v_b, a_b, mm_b = simulate_bezier_jerk(v0, v1, accel, mm_total)

exec_q, dev_q = bresenham_axis_check(mm_q, steps_per_mm, axis_ratios, None)
exec_b, dev_b = bresenham_axis_check(mm_b, steps_per_mm, axis_ratios, None)

print("=== Multi-axis lockstep check ===")
print(f"{'axis':<4} {'quantized: steps / max dev':<28} {'bezier: steps / max dev'}")
for ax in axis_ratios:
    print(f"{ax:<4} {exec_q[ax]:>6d} / {dev_q[ax]:<6.2f} steps      "
          f"{exec_b[ax]:>6d} / {dev_b[ax]:<6.2f} steps")

print("\n=== Ramp smoothness check ===")
da_q = np.diff(a_q) / np.diff(np.append(t_q[0], t_q[1:]))
print(f"quantized ramp: {len(t_q)-1} segments, max |d(accel)/dt jump| between "
      f"consecutive segments = {np.max(np.abs(np.diff(a_q))):.2f} mm/min^2 per segment "
      f"(stairstep size)")
print(f"bezier ramp:    {len(t_b)-1} segments, accel is a continuous function of "
      f"elapsed ramp time -- no per-segment discontinuity by construction")
print(f"quantized ramp final speed = {v_q[-1]:.1f} mm/min in {t_q[-1]*60:.3f}s "
      f"(target v1={v1:.0f})")
print(f"bezier ramp final speed    = {v_b[-1]:.1f} mm/min in {t_b[-1]*60:.3f}s "
      f"(target v1={v1:.0f}, theoretical constant-accel time = {(v1-v0)/accel*60:.3f}s)")

fig, axs = plt.subplots(2, 1, figsize=(7, 7), sharex=True)
axs[0].step(t_q*60, v_q, where="post", label="quantized (grblHAL current)", color="#2a78d6")
axs[0].plot(t_b*60, v_b, label="quintic bezier (this patch)", color="#eb6834")
axs[0].set_ylabel("velocity (mm/min)")
axs[0].legend()
axs[1].step(t_q*60, a_q, where="post", label="quantized accel (stairstep)", color="#2a78d6")
axs[1].plot(t_b*60, np.gradient(v_b, t_b*60/60), label="bezier accel (continuous)", color="#eb6834")
axs[1].set_ylabel("acceleration (mm/min^2)")
axs[1].set_xlabel("time (s)")
axs[1].legend()
plt.tight_layout()
plt.savefig("/home/claude/bezier_validation.png", dpi=130)
print("\nSaved plot: bezier_validation.png")
